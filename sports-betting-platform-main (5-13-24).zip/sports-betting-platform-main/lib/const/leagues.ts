export const leagues = [
  2,    // UEFA Champions League
  3,    // UEFA Europa League
  22,   // Concacaf W Gold Cup
  29,   // FIFA World Cup Qualifying - CAF
  30,   // FIFA World Cup Qualifying - AFC
  34,   // FIFA World Cup Qualifying - Conmebol
  39,   // English Premier League
  40,   // English League Champoinship
  45,   // English FA Cup
  48,   // English Carabao Cup
  61,   // French Ligue1
  78,   // Germany Bundesliga
  135,  // Italian Serie A
  140,  // Spanish La Liga
  253,  // MLS
  262,  // Mexican Liga BBVA MX
  536,  // Concacaf Nations League
  960,  // UEFA European Championship Qualifying
]